window.addEventListener('load', () => {
    Average()
});
document.querySelector('.ui-selectonemenu-panel').addEventListener('click', () => {
    sleep(500).then(Average)
})

function Average() {
    const tableBody = document.querySelector("tbody.ui-datatable-data.ui-widget-content")
    const tableHead = tableBody.parentNode.children[0]
    tableHead.querySelector("tr").innerHTML += `<th id="marksForm:marksWidget:coursesTable:j_idt191" class="ui-state-default" role="columnheader" style="width:55px;text-align: center"><span class="ui-column-title">Moyennes</span></th>`
    const tableBodyChildrens = tableBody.children

    let totalMoyenne = 0
    let globalTotalCoef = 0
    let examsTotalCoef = 0
    let ccTotalCoef = 0
    let totalCC = 0
    let totalExams = 0

    for (let i = 0; i < tableBodyChildrens.length; i++) {
        let data = tableBodyChildrens[i].innerText.split('\t')
        let dataLength = data.length
        const coef = parseInt(data[2])

        let notes = []

        for (let j = 4; j < dataLength - 1; j++) {
            if (data[j] !== '') {
                const note = data[j].replace(',', '.')
                notes.push(note)
            }
        }

        let totalNotes = null
        let moyenne = null

        if (notes.length !== 0) {
            let n = 0
            while (n < notes.length) {
                (totalNotes === null) ? totalNotes = parseFloat(notes[n].replace(',', '.')) : totalNotes += parseFloat(notes[n].replace(',', '.'));
                n++
            }

            moyenne = (totalNotes / notes.length)
            totalCC += (moyenne * coef)

            ccTotalCoef += coef
        }

        if (data[dataLength - 1] !== '') {
            const noteExam = parseFloat(data[dataLength - 1].replace(',', '.'));
            (moyenne === null) ? moyenne = 0 : moyenne = parseFloat(moyenne);
            if (totalNotes === null) {
                moyenne = noteExam
            } else {
                moyenne = (moyenne + noteExam) / 2
            }
            totalExams += (noteExam * coef)
            examsTotalCoef += coef
        }

        (moyenne === null) ? moyenne = '' : moyenne = moyenne.toFixed(2);
        tableBodyChildrens[i].innerHTML += `<td role="gridcell" style="text-align: center">${moyenne}</td>`;


        if (!isNaN(coef)) {

            (moyenne === '') ? moyenne = 0 : moyenne;

            if (moyenne !== 0) {
                totalMoyenne += moyenne * coef
                globalTotalCoef += coef
            }
        }

        //interessant = 2 (coef) | last (exam) | 4 → last-1 (notes)
    }
    if (!isNaN(totalMoyenne / globalTotalCoef)) {
        const moyenneGeneral = (totalMoyenne / globalTotalCoef).toFixed(2)
        const moyenneCC = (totalCC / ccTotalCoef).toFixed(2)
        const moyenneExams = (totalExams / examsTotalCoef).toFixed(2)
        tableBody.parentNode.parentNode.innerHTML += `<div style="display: flex; justify-content: flex-end; width:calc(100% -20px); gap: 10%; padding: 4px 10px;font-size: 125% ">
            <div style="color: #217bb1; font-weight: bold">Moyenne CC : ${moyenneCC}</div>
            <div style="color: #217bb1; font-weight: bold">Moyenne Exams : ${moyenneExams}</div>
            <div style="color: #217bb1; font-weight: bold">Moyenne Générale : ${moyenneGeneral}</div>
            </div>`
    }

}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}